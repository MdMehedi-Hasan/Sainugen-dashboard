import React from 'react';
import './App.css';
import Drawer from './Components/Drawer';

function App() {
  return (
    <div>
      <Drawer />
    </div>
  );
}

export default App;
